<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define("DB_HOST", "localhost");
define("DB_NAME", "crud_camisas");
define("DB_USER", "newuser");
define("DB_PASSWORD", "password");
define("BASE_URL", "/crud-camisas");